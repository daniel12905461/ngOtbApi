<?php

namespace Database\Factories;

use App\Models\Lectura;
use Illuminate\Database\Eloquent\Factories\Factory;

class LecturaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Lectura::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
